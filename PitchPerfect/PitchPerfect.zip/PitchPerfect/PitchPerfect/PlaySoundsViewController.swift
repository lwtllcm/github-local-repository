//
//  PlaySoundsViewController.swift
//  PitchPerfect
//
//  Created by Laurie Wheeler on 11/1/15.
//  Copyright © 2015 Student. All rights reserved.
//

import UIKit
import AVFoundation

class PlaySoundsViewController: UIViewController {

    var audioPlayer = AVAudioPlayer!()
    var echoPlayer = AVAudioPlayer!()
    var receivedAudio: RecordedAudio!
    var audioEngine: AVAudioEngine!
    var audioFile: AVAudioFile!

    override func viewDidLoad() {
        super.viewDidLoad()

        audioPlayer = try! AVAudioPlayer(contentsOfURL: receivedAudio.filePathUrl)
        echoPlayer = try! AVAudioPlayer(contentsOfURL: receivedAudio.filePathUrl)
        
        audioPlayer.enableRate = true
        audioEngine = AVAudioEngine()
        audioFile = try! AVAudioFile(forReading: receivedAudio.filePathUrl)
        audioFile = try! AVAudioFile(forReading: receivedAudio.filePathUrl)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func playSlow(sender: AnyObject) {
        playAudioWithVariableRate(0.5)
    }

    @IBAction func playFast(sender: UIButton) {
        playAudioWithVariableRate(1.5)
    }

    @IBAction func playChipmunk(sender: UIButton) {
        playAudioWithVariablePitch(1000)
    }

    @IBAction func playDarthVader(sender: UIButton) {
        playAudioWithVariablePitch(-1000)
    }

    // playEcho is based on code in http://sandmemory.blogspot.com/2014/12/how-would-you-add-reverbecho-to-audio.html
    
    @IBAction func playEcho(sender: UIButton) {
        stopAudio()
        audioPlayer.currentTime = 0.0
        audioPlayer.play()

        let shortDelay: NSTimeInterval = 0.7
        let delayStart = echoPlayer.deviceCurrentTime + shortDelay
        echoPlayer.volume = 0.8
        echoPlayer.playAtTime(delayStart)
    }
    
    @IBAction func playReverb(sender: AnyObject) {
        let audioUnitReverb = AVAudioUnitReverb()
        let audioUnitReverbPreset = AVAudioUnitReverbPreset.Cathedral
        audioUnitReverb.loadFactoryPreset(audioUnitReverbPreset)
        audioUnitReverb.wetDryMix = 50
        playAudioWithSpecialEffect(audioUnitReverb)
    }
    
    func playAudioWithVariableRate(variableRate: Float) {
        stopAudio()
        audioPlayer.currentTime = 0.0
        audioPlayer.rate = variableRate
        audioPlayer.play()
    }
    
    func playAudioWithVariablePitch(pitch: Float) {
        let changePitchEffect = AVAudioUnitTimePitch()
        changePitchEffect.pitch = pitch
        playAudioWithSpecialEffect(changePitchEffect)
    }
    
    func playAudioWithSpecialEffect(effectNode:AnyObject) {
        stopAudio()
        let audioPlayerNode = AVAudioPlayerNode()
        audioEngine.attachNode(audioPlayerNode)
        audioEngine.attachNode(effectNode as! AVAudioNode)

        audioEngine.connect(audioPlayerNode, to: effectNode as! AVAudioNode, format: nil)
        audioEngine.connect(effectNode as! AVAudioNode, to: audioEngine.outputNode, format: nil)

        audioPlayerNode.scheduleFile(audioFile, atTime: nil, completionHandler: nil)
        try! audioEngine.start()
        audioPlayerNode.play()
    }

    @IBAction func stopPlay(sender: UIButton) {
        stopAudio()
    }
    
    func stopAudio() {
        audioPlayer.stop()
        echoPlayer.stop()
        audioEngine.stop()
        audioEngine.reset()
    }
}
