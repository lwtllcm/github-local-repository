//
//  RecordedAudio.swift
//  PitchPerfect
//
//  Created by Laurie Wheeler on 11/4/15.
//  Copyright © 2015 Student. All rights reserved.
//

import Foundation

class  RecordedAudio {
    var filePathUrl: NSURL!
    var title: String!
    
   
    
    init(filePathUrl: NSURL, title: String) {

        self.filePathUrl = filePathUrl
        self.title = self.filePathUrl.lastPathComponent
        
        print("in RecordedAudio %", self.filePathUrl)
        print("in RecordedAudio %", self.title)
    }
    
    
   }


