//
//  RecordSoundsViewController.swift
//  PitchPerfect
//
//  Created by Laurie Wheeler on 10/30/15.
//  Copyright © 2015 Student. All rights reserved.
//

import UIKit
import AVFoundation

class RecordSoundsViewController: UIViewController, AVAudioRecorderDelegate {

    @IBOutlet weak var recordingInProgress: UILabel!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var pauseButton: UIButton!
    
    var audioRecorder: AVAudioRecorder!
    var recordedAudio: RecordedAudio!
    var recordedAudioExists:Bool = false

    override func viewWillAppear(animated: Bool) {

        stopButton.hidden = true
        recordingInProgress.text = "Tap to Record"
        recordingInProgress.hidden = false
        recordButton.enabled = true
        pauseButton.hidden = true
        recordedAudioExists = false
    }

    @IBAction func recordAudio(sender: UIButton) {
        stopButton.hidden = false
        recordingInProgress.text = "Recording in Progress"
        recordingInProgress.hidden = false
        recordButton.enabled = false

        pauseButton.hidden = false

        if recordedAudioExists {
            audioRecorder.record()
        }
        else {
        recordedAudioExists = true
        let dirPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true) [0] as String

        let recordingName = "my_audio.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = NSURL.fileURLWithPathComponents(pathArray)

        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(AVAudioSessionCategoryPlayAndRecord)

        try! audioRecorder = AVAudioRecorder(URL: filePath!, settings: [:])
        audioRecorder.delegate = self
        audioRecorder.meteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
        }
    }

    func audioRecorderDidFinishRecording(recorder: AVAudioRecorder, successfully flag: Bool) {

        if (flag) {
            recordedAudio = RecordedAudio(filePathUrl: recorder.url, title: recorder.url.lastPathComponent!)
            performSegueWithIdentifier("stopRecording", sender: recordedAudio)
        }else{
            print("Recording was not successful")
            recordButton.enabled = true
            stopButton.hidden = true
        }
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "stopRecording") {
            let playSoundsVC:PlaySoundsViewController = segue.destinationViewController as! 
                PlaySoundsViewController
            let data = sender as! RecordedAudio
            playSoundsVC.receivedAudio = data
        }
    }

    @IBAction func pauseRecord(sender: UIButton) {
        recordingInProgress.text = "Tap to Resume"
        audioRecorder.pause()
        stopButton.hidden = true
        pauseButton.hidden = true
        recordButton.enabled = true
    }

    @IBAction func stopRecord(sender: UIButton) {
        recordingInProgress.hidden = true

        audioRecorder.stop()
        let audioSession = AVAudioSession.sharedInstance()
        try! audioSession.setActive(false)
    }
}
